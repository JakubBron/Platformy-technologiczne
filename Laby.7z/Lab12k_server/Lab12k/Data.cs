﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab12k
{
    class Data
    {
        public int NumberA { get; set; }
        public int NumberB { get; set; }
        public int? Result { get; set; }
        public string Content { get; set; } = string.Empty;
    }
}
